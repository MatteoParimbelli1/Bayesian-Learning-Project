## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE,
                      fig.align = "center", cache = FALSE)

library(dplyr)
library(tidyr)
library(ggplot2)
library(corrplot)
library(caret)
library(RColorBrewer)

rm(list = ls())
set.seed(2026)


## -----------------------------------------------------------------------------
# dataset loading

raw <- read.csv("../data/Airline_customer_satisfaction.csv", stringsAsFactors = FALSE)

# manually set "satisfied" class encoding to 1 (later use)
raw <- raw %>%
  mutate(
    satisfaction   = factor(satisfaction, levels = c("dissatisfied", "satisfied")),
    # even if for this variables their factor won't be relevant during prediction,  is still useful for data exploration
    Class          = factor(Class, levels = c("Eco", "Eco Plus", "Business")),
    # levels are pinned explicitly: these two feed `strata` below, and
    # createDataPartition walks the strata in level order, so an implicit
    # factor() would make the train/test split depend on locale collation.
    # This order is the one that produced the committed split.
    Customer.Type  = factor(Customer.Type,  levels = c("disloyal Customer", "Loyal Customer")),
    Type.of.Travel = factor(Type.of.Travel, levels = c("Business travel", "Personal Travel"))
  )



## -----------------------------------------------------------------------------
new_names <- c(
  "satisfaction", "customer_type", "age", "travel_type", "class",
  "flight_distance", "seat_comfort", "time_convenient", "food_drink",
  "gate_location", "wifi", "entertainment", "online_support", "ease_booking",
  "onboard_service", "legroom", "baggage", "checkin", "cleanliness",
  "online_boarding", "dep_delay", "arr_delay"
)

names(raw) <- new_names
dim(raw)


## -----------------------------------------------------------------------------
# find and locate missing values
na_counts <- colSums(is.na(raw))
na_counts[na_counts > 0]


## -----------------------------------------------------------------------------
nrow(raw)
raw <- raw %>% filter(!is.na(arr_delay))
raw$row_id <- seq_len(nrow(raw))
nrow(raw)


## -----------------------------------------------------------------------------
# general info
str(raw)

# check for duplicated rows
cat("Duplicated rows:", sum(duplicated(raw)), "\n")


## -----------------------------------------------------------------------------
col_filter = c("age", "flight_distance", "seat_comfort", "time_convenient", "food_drink", "gate_location", "wifi", "entertainment", "online_support", "ease_booking", "onboard_service", "legroom", "baggage", "checkin", "cleanliness", "online_boarding", "dep_delay")

sapply(raw[col_filter], range)


## -----------------------------------------------------------------------------
# check and lot target class balance

pal <- c(dissatisfied = "#eb6834", satisfied = "#2a78d0")

bal <- raw %>%
  count(satisfaction) %>%
  mutate(share = n / sum(n),
         satisfaction = factor(satisfaction, levels = c("dissatisfied", "satisfied")))

ggplot(bal, aes(satisfaction, n, fill = satisfaction)) +
  geom_col(width = 0.6, show.legend = FALSE) +
  geom_text(aes(label = sprintf("%d\n(%.1f%%)", n, 100 * share)),
            vjust = -0.3, size = 4, colour = "#52514e", lineheight = 0.95) +
  scale_fill_manual(values = pal) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.18))) +
  labs(title = "Class balance of the target variable",
       x = NULL, y = "customers") +
  theme_minimal(base_size = 12) +
  theme(panel.grid.major.x = element_blank(), panel.grid.minor = element_blank())


## -----------------------------------------------------------------------------
# we modify categorical variables in order to show them in the boxplots and correlation matrix

num.raw = raw
cat_vars = names(num.raw)[!sapply(num.raw, is.numeric)]

mappings <- lapply(num.raw[cat_vars], levels)
num.raw[cat_vars] <- lapply(num.raw[cat_vars], as.integer)


## ----fig.width=16, fig.height=14----------------------------------------------
num.raw %>%
  select(where(is.numeric)) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "value") %>%
  ggplot(aes(x = variable, y = value, fill = variable)) +
  geom_boxplot(show.legend = FALSE) +
  facet_wrap(~ variable, scales = "free") +
  scale_fill_viridis_d() +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())


## ----fig.width=14, fig.height=14----------------------------------------------
qs_vars <- c("seat_comfort", "time_convenient", "food_drink", "gate_location", "wifi", "entertainment", "online_support", "ease_booking", "onboard_service", "legroom", "baggage", "checkin", "cleanliness", "online_boarding")

raw %>%
  select(satisfaction, all_of(qs_vars)) %>%
  pivot_longer(-satisfaction, names_to = "item", values_to = "rating") %>%
  ggplot(aes(x = satisfaction, y = rating, fill = satisfaction)) +
  geom_boxplot(outlier.size = 0.4, alpha = 0.85) +
  facet_wrap(~ item, ncol = 4, scales = "free_y") +
  scale_fill_manual(values = c("dissatisfied" = "#D85A30", "satisfied" = "#3B6D11")) +
  labs(title = "Service-quality ratings by satisfaction outcome",
       x = NULL, y = "Rating (0-5)") +
  theme_minimal(base_size = 9) +
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 0),
        strip.text = element_text(face = "bold", size = 7.5))


## ----fig.width=16, fig.height=16----------------------------------------------

corr_mat = cor(num.raw[, !names(num.raw) == "row_id"])

corrplot(corr_mat, method = "color", type = "upper", order = "hclust",
         col = colorRampPalette(rev(brewer.pal(9, "RdBu")))(200),
         tl.col = "black", tl.srt = 45, tl.cex = 0.75,
         addCoef.col = "black", number.cex = 0.55,
         diag = FALSE,
         title = "Correlation matrix of all original and augmented covariates",
         mar = c(0, 0, 2, 0))


## ----fig.width=14, fig.height=14----------------------------------------------
# focus on the correlation between Quality of Service variables

# re-defining them for clarity
qs_vars <- c("seat_comfort", "time_convenient", "food_drink", "gate_location", "wifi", "entertainment", "online_support", "ease_booking", "onboard_service", "legroom", "baggage", "checkin", "cleanliness", "online_boarding")


qs_corr <- cor(num.raw[, qs_vars], use = "pairwise.complete.obs")

corrplot(qs_corr, method = "color", type = "upper", order = "hclust",
         col = colorRampPalette(rev(brewer.pal(9, "RdBu")))(200),
         tl.col = "black", tl.srt = 45, tl.cex = 0.75,
         addCoef.col = "black", number.cex = 0.55,
         diag = FALSE,
         title = "Correlation matrix of the 14 service-quality variables",
         mar = c(0, 0, 2, 0))


## -----------------------------------------------------------------------------
cluster_range <- function(items) {
  sub <- qs_corr[items, items]
  vals <- sub[upper.tri(sub)]
  sprintf("%.2f-%.2f", min(vals), max(vals))
}


cluster_booking  <- c("wifi", "entertainment", "online_support", "ease_booking")

cluster_onboard  <- c("onboard_service", "legroom", "baggage")

cluster_catering <- c("seat_comfort", "food_drink", "gate_location")

r_booking  <- cluster_range(cluster_booking)
r_onboard  <- cluster_range(cluster_onboard)
r_catering <- cluster_range(cluster_catering)

r_booking
r_onboard
r_catering


## ----structural-zeros---------------------------------------------------------
zero_share <- sort(sapply(raw[, qs_vars], function(x) mean(x == 0)),
                    decreasing = TRUE)

knitr::kable(
  data.frame(item = names(zero_share), zero_share = round(zero_share, 3)),
  row.names = FALSE, col.names = c("Service item", "Share of rows = 0"),
  caption = "Share of rows recording a 0 rating, by service item"
)


## -----------------------------------------------------------------------------
zero_candidates <- names(zero_share)[zero_share > 0.02]

raw <- raw %>%
  mutate(structural_zero_flag = if_any(all_of(zero_candidates), ~ .x == 0))

n_flagged <- sum(raw$structural_zero_flag)
n_flagged


## ----delay-collinearity-------------------------------------------------------
delay_cor <- cor(raw$dep_delay, raw$arr_delay, use = "complete.obs")
n_missing_arr <- sum(is.na(raw$arr_delay))


## ----delay-residual-----------------------------------------------------------
# exploring the 

delay_fit <- lm(arr_delay ~ dep_delay, data = raw)
raw$arr_delay_res <- residuals(delay_fit)

check_cor <- cor(raw$dep_delay, raw$arr_delay, use = "complete.obs")


## -----------------------------------------------------------------------------
raw$midfly_delay <- raw$arr_delay - raw$dep_delay


## -----------------------------------------------------------------------------
raw[, c("flight_distance", "dep_delay", "midfly_delay")] %>%
  select(where(is.numeric)) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "value") %>%
  ggplot(aes(x = variable, y = value, fill = variable)) +
  geom_boxplot(show.legend = FALSE) +
  facet_wrap(~ variable, scales = "free") +
  scale_fill_viridis_d() +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())


## ----skew-check---------------------------------------------------------------
skew <- function(x) { x <- x[!is.na(x)]; m <- mean(x); s <- sd(x); mean(((x - m) / s)^3) }

signedLogArr <- sign(raw$midfly_delay) * log1p(abs(raw$midfly_delay))

skew_tbl <- data.frame(
  variable = c("Flight Distance", "log1p(Flight Distance)",
               "Departure Delay", "log1p(Departure Delay)",
               "Midflight Delay", "signed-log(Midflight delay)"
               ),
  skewness = round(c(
    skew(raw$flight_distance), skew(log1p(raw$flight_distance)), 
    skew(raw$dep_delay), skew(log1p(raw$dep_delay)),
    skew(raw$midfly_delay), skew(signedLogArr)
    ), 3)
)
knitr::kable(skew_tbl)


## -----------------------------------------------------------------------------
raw$log_mid_delay <- signedLogArr
raw$log_dep_delay <- log1p(raw$dep_delay)


## ----fig.width=16, fig.height=16----------------------------------------------

new_corr_mat = cor(num.raw[, !names(num.raw) == "row_id"])
# arr_delay_res is excluded due problems during the plotting

corrplot(new_corr_mat, method = "color", type = "upper", order = "hclust",
         col = colorRampPalette(rev(brewer.pal(9, "RdBu")))(200),
         tl.col = "black", tl.srt = 45, tl.cex = 0.75,
         addCoef.col = "black", number.cex = 0.55,
         diag = FALSE,
         title = "Correlation matrix of all original and augmented covariates",
         mar = c(0, 0, 2, 0))


## ----fig.width=14, fig.height=14----------------------------------------------

cat_vars <- c("satisfaction", "customer_type", "travel_type", "class")

lapply(raw[cat_vars], function(x) round(prop.table(table(x)), 3))


## -----------------------------------------------------------------------------
set.seed(123)

strata <- interaction(raw$satisfaction, raw$class, raw$customer_type, raw$travel_type, drop = TRUE)
train_idx <- createDataPartition(y = strata, p = 1200 / nrow(raw), list = FALSE)
  
train_df <- raw[train_idx, ]
test_df  <- raw[-train_idx, ]


## ----stratification-check-----------------------------------------------------
compare_tbl <- function(var) {
  full  <- prop.table(table(raw[[var]]))
  train <- prop.table(table(train_df[[var]]))
  round(cbind(full = full, train = train), 3)
}

cat("Satisfaction proportions (full data vs. training subsample):\n")
print(compare_tbl("satisfaction"))

cat("\nClass proportions (full data vs. training subsample):\n")
print(compare_tbl("class"))

cat("\nCustomer Type proportions (full data vs. training subsample):\n")
print(compare_tbl("customer_type"))


## ----save-outputs-------------------------------------------------------------
saveRDS(raw, "../data/airline_full_clean.rds")
write.csv(train_df, "../data/airline_train_n1200.csv", row.names = FALSE)
write.csv(test_df,  "../data/airline_test_holdout.csv", row.names = FALSE)

