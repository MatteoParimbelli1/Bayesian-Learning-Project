## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE,
                       fig.align = "center", cache = FALSE)

library(dplyr)
library(tidyr)
library(ggplot2)


## ----load---------------------------------------------------------------------
test <- read.csv("../data/airline_test_holdout.csv", stringsAsFactors = FALSE)
test$y <- as.integer(test$satisfaction == "satisfied")
n_test <- nrow(test)

s2 <- readRDS("../data/02_logit_mcmc.rds")
s3 <- readRDS("../data/03_horseshoe_final.rds")

invlogit <- function(x) 1 / (1 + exp(-x))


## ----test-covariates----------------------------------------------------------
std_with <- function(x, mean, sd) (x - mean) / sd

logDepDelay_test  <- log1p(test$dep_delay)
signedLogArr_test <- test$log_mid_delay

Class_EcoPlus_test  <- as.integer(test$class == "Eco Plus")
Class_Business_test <- as.integer(test$class == "Business")
TypeTravel_Personal_test <- as.integer(test$travel_type == "Personal Travel")
CustType_disloyal_test   <- as.integer(test$customer_type == "disloyal Customer")

n_missing_test <- sum(is.na(signedLogArr_test))


## ----test-covariates-2--------------------------------------------------------
# --- Section 02 design (dummy Class, 8 covariates) ---
X_test_s2 <- cbind(
  Age_std        = std_with(test$age, s2$standardization$Age_mean, s2$standardization$Age_sd),
  Seat_std       = std_with(test$seat_comfort, s2$standardization$Seat_mean, s2$standardization$Seat_sd),
  FlightDist_std = std_with(test$flight_distance, s2$standardization$FlightDist_mean, s2$standardization$FlightDist_sd),
  Class_EcoPlus  = Class_EcoPlus_test,
  Class_Business = Class_Business_test,
  logDepDelay_std = std_with(logDepDelay_test, s2$standardization$logdep_mean, s2$standardization$logDepDelay_sd),
  TypeTravel_Personal = TypeTravel_Personal_test,
  CustType_disloyal   = CustType_disloyal_test
)
arr_delay_test_s2 <- std_with(signedLogArr_test, s2$standardization$logmid_mean, s2$standardization$logmid_sd)
arr_delay_test_s2[is.na(arr_delay_test_s2)] <- 0

# --- Section 03 design (14 service items + covariates) ---
service_items <- s3$service_items
X_service_test <- sapply(service_items, function(nm) {
  std_with(test[[nm]], s3$standardization$service_means[nm], s3$standardization$service_sds[nm])
})
X_extra_test <- cbind(
  Age_std        = std_with(test$age, s3$standardization$Age_mean, s3$standardization$Age_sd),
  FlightDist_std = std_with(test$flight_distance, s3$standardization$FlightDist_mean, s3$standardization$FlightDist_sd),
  Class_EcoPlus  = Class_EcoPlus_test,
  Class_Business = Class_Business_test,
  logDepDelay_std = std_with(logDepDelay_test, s3$standardization$logDepDelay_mean, s3$standardization$logDepDelay_sd),
  TypeTravel_Personal = TypeTravel_Personal_test,
  CustType_disloyal   = CustType_disloyal_test
)
X_test_s3 <- cbind(X_service_test, X_extra_test)
arr_delay_test_s3 <- std_with(signedLogArr_test, s3$standardization$logmid_mean, s3$standardization$logmid_sd)
arr_delay_test_s3[is.na(arr_delay_test_s3)] <- 0


## ----predict-function---------------------------------------------------------
predict_model <- function(beta_draws, X, arr_delay, group_vars = NULL) {
  S <- nrow(beta_draws)
  N <- nrow(X)
  beta_cols <- grep("^beta\\[", colnames(beta_draws), value = TRUE)
  beta_cols <- beta_cols[order(as.numeric(gsub("beta\\[|\\]", "", beta_cols)))]
  Bmat  <- beta_draws[, beta_cols, drop = FALSE]
  beta0 <- beta_draws[, "beta0"]
  barr  <- beta_draws[, "beta_arr"]

  p_sum <- numeric(N)
  group_rep <- if (!is.null(group_vars)) {
    lapply(group_vars, function(g) matrix(NA_real_, nrow = S, ncol = length(unique(g)),
                                            dimnames = list(NULL, sort(unique(g)))))
  } else NULL
  names(group_rep) <- names(group_vars)

  for (s in seq_len(S)) {
    lin <- beta0[s] + as.vector(X %*% Bmat[s, ]) + barr[s] * arr_delay
    p <- invlogit(lin)
    p_sum <- p_sum + p
    if (!is.null(group_vars)) {
      y_rep <- rbinom(N, 1, p)
      for (gname in names(group_vars)) {
        g <- group_vars[[gname]]
        rates <- tapply(y_rep, g, mean)
        group_rep[[gname]][s, names(rates)] <- rates
      }
    }
  }
  list(p_mean = p_sum / S, group_rep = group_rep)
}

set.seed(123)
pred_s2 <- predict_model(s2$beta_draws, X_test_s2, arr_delay_test_s2)
pred_s3 <- predict_model(s3$beta_draws, X_test_s3, arr_delay_test_s3,
                          group_vars = list(Class = test$class, CustomerType = test$customer_type,
                                             TypeOfTravel = test$travel_type))

p_s2 <- pred_s2$p_mean
p_s3 <- pred_s3$p_mean


## ----bas-predict--------------------------------------------------------------
suppressMessages(library(BAS))
fit_bas <- readRDS("../data/A01_BAS_model.rds")

df_test_bas <- data.frame(
  X_service_test,
  Age_std = X_extra_test[, "Age_std"], FlightDist_std = X_extra_test[, "FlightDist_std"],
  Class_EcoPlus = X_extra_test[, "Class_EcoPlus"], Class_Business = X_extra_test[, "Class_Business"],
  # Column names must match fit_bas$namesx exactly: BAS rebuilds the model
  # frame from the formula, so a renamed column is simply a missing variable.
  logdep_std = X_extra_test[, "logDepDelay_std"],
  TypeTravel_Personal = X_extra_test[, "TypeTravel_Personal"],
  CustType_disloyal = X_extra_test[, "CustType_disloyal"],
  logmid_delay = arr_delay_test_s3
)

# BAS's predict(..., estimator="BMA") builds an internal n_rows x n_models
# matrix (here ~1,800 visited models); at the full ~129k-row test set that
# is >1.5GB, which was enough to get the R process OOM-killed.
# Predicting in batches keeps peak memory bounded to a few hundred MB.
predict_bas_batched <- function(fit, newdata, batch_size = 10000) {
  n <- nrow(newdata)
  out <- numeric(n)
  for (st in seq(1, n, by = batch_size)) {
    en <- min(st + batch_size - 1, n)
    out[st:en] <- predict(fit, newdata = newdata[st:en, ], type = "response", estimator = "BMA")$fit
    invisible(gc(full = TRUE))
  }
  out
}

p_bas <- predict_bas_batched(fit_bas, df_test_bas)


## ----auc-function-------------------------------------------------------------
auc_mw <- function(probs, labels) {
  r <- rank(probs)
  n1 <- as.numeric(sum(labels == 1)); n0 <- as.numeric(sum(labels == 0))
  (sum(r[labels == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
brier <- function(probs, labels) mean((probs - labels)^2)

model_cmp <- data.frame(
  model = c("Section 02 (vague, 9 predictors)", "Section 03 (horseshoe, 22 predictors)",
            "Section 04 (BAS, BMA over model space)"),
  AUC   = c(auc_mw(p_s2, test$y), auc_mw(p_s3, test$y), auc_mw(p_bas, test$y)),
  Brier = c(brier(p_s2, test$y), brier(p_s3, test$y), brier(p_bas, test$y))
)
knitr::kable(model_cmp, digits = 4)


## ----roc-3way, fig.width=6.5, fig.height=5.5----------------------------------
roc_s2  <- compute_roc_curve <- function(probs, labels, n_thresh = 100) {
  thresholds <- seq(0, 1, length.out = n_thresh)
  sapply(thresholds, function(t) {
    pred <- as.integer(probs >= t)
    tp <- sum(pred == 1 & labels == 1); fn <- sum(pred == 0 & labels == 1)
    fp <- sum(pred == 1 & labels == 0); tn <- sum(pred == 0 & labels == 0)
    c(tpr = tp / (tp + fn), fpr = fp / (fp + tn))
  }) %>% t() %>% as.data.frame()
}

roc_all <- bind_rows(
  compute_roc_curve(p_s2, test$y) %>% mutate(model = sprintf("Section 02 (AUC=%.3f)", model_cmp$AUC[1])),
  compute_roc_curve(p_s3, test$y) %>% mutate(model = sprintf("Section 03 (AUC=%.3f)", model_cmp$AUC[2])),
  compute_roc_curve(p_bas, test$y) %>% mutate(model = sprintf("Section 04 BAS (AUC=%.3f)", model_cmp$AUC[3]))
)

ggplot(roc_all, aes(fpr, tpr, color = model)) +
  geom_line(linewidth = 1) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey60") +
  labs(title = "Test-set ROC: all three model families", x = "False positive rate", y = "True positive rate",
       color = NULL) +
  theme_minimal(base_size = 10) +
  theme(legend.position = "bottom")


## ----roc-curve, fig.width=6, fig.height=5-------------------------------------
compute_roc <- function(probs, labels, n_thresh = 200) {
  thresholds <- seq(0, 1, length.out = n_thresh)
  sapply(thresholds, function(t) {
    pred <- as.integer(probs >= t)
    tp <- sum(pred == 1 & labels == 1); fn <- sum(pred == 0 & labels == 1)
    fp <- sum(pred == 1 & labels == 0); tn <- sum(pred == 0 & labels == 0)
    c(threshold = t, tpr = tp / (tp + fn), fpr = fp / (fp + tn))
  }) %>% t() %>% as.data.frame()
}

roc_df <- compute_roc(p_s3, test$y)
auc_val <- auc_mw(p_s3, test$y)

ggplot(roc_df, aes(fpr, tpr)) +
  geom_line(color = "#185FA5", linewidth = 1) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey60") +
  labs(title = sprintf("Test-set ROC (AUC = %.3f)", auc_val),
       x = "False positive rate", y = "True positive rate") +
  theme_minimal(base_size = 11)


## ----confusion-matrices-------------------------------------------------------
make_confusion <- function(probs, labels, threshold) {
  pred <- as.integer(probs >= threshold)
  tab <- table(Predicted = pred, Actual = labels)
  sens <- tab["1","1"] / sum(tab[,"1"])
  spec <- tab["0","0"] / sum(tab[,"0"])
  acc  <- sum(diag(tab)) / sum(tab)
  list(table = tab, sensitivity = sens, specificity = spec, accuracy = acc)
}

base_rate <- mean(read.csv("../data/airline_train_n1200.csv", stringsAsFactors = FALSE)$satisfaction == "satisfied")

cm_05   <- make_confusion(p_s3, test$y, 0.5)
cm_base <- make_confusion(p_s3, test$y, base_rate)

cat("--- Threshold = 0.5 ---\n"); print(cm_05$table)
cat(sprintf("Sensitivity: %.3f  Specificity: %.3f  Accuracy: %.3f\n\n",
            cm_05$sensitivity, cm_05$specificity, cm_05$accuracy))

cat(sprintf("--- Threshold = base rate (%.3f) ---\n", base_rate)); print(cm_base$table)
cat(sprintf("Sensitivity: %.3f  Specificity: %.3f  Accuracy: %.3f\n",
            cm_base$sensitivity, cm_base$specificity, cm_base$accuracy))


## ----calibration, fig.width=6, fig.height=5-----------------------------------
calib_df <- data.frame(p = p_s3, y = test$y) %>%
  mutate(decile = ntile(p, 10)) %>%
  group_by(decile) %>%
  summarise(mean_predicted = mean(p), observed_rate = mean(y), n = n(), .groups = "drop")

knitr::kable(calib_df, digits = 3, caption = "Calibration by decile of predicted probability")

ggplot(calib_df, aes(mean_predicted, observed_rate)) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey60") +
  geom_point(size = 2.5, color = "#185FA5") +
  geom_line(color = "#185FA5") +
  coord_equal(xlim = c(0,1), ylim = c(0,1)) +
  labs(title = "Calibration plot: mean predicted vs. observed satisfaction rate",
       x = "Mean predicted probability (decile)", y = "Observed satisfaction rate") +
  theme_minimal(base_size = 11)

cat(sprintf("Brier score (horseshoe): %.4f\n", brier(p_s3, test$y)))


## ----ppc-plot, fig.width=9, fig.height=3.5------------------------------------
observed_rates <- list(
  Class = tapply(test$y, test$class, mean),
  CustomerType = tapply(test$y, test$customer_type, mean),
  TypeOfTravel = tapply(test$y, test$travel_type, mean)
)

ppc_df <- bind_rows(lapply(names(pred_s3$group_rep), function(gname) {
  mat <- pred_s3$group_rep[[gname]]
  as.data.frame(mat) %>%
    pivot_longer(everything(), names_to = "level", values_to = "simulated_rate") %>%
    mutate(facet = gname)
}))

obs_df <- bind_rows(lapply(names(observed_rates), function(gname) {
  data.frame(level = names(observed_rates[[gname]]), observed = as.numeric(observed_rates[[gname]]),
             facet = gname)
}))

p_ppc <- ggplot(ppc_df, aes(simulated_rate, fill = level)) +
  geom_density(alpha = 0.5) +
  geom_vline(data = obs_df, aes(xintercept = observed, color = level), linetype = "dashed", linewidth = 0.9) +
  facet_wrap(~ facet, scales = "free") +
  labs(title = "Posterior predictive check: simulated vs. observed subgroup satisfaction rate",
       subtitle = "Dashed lines = actually observed rate in the held-out test set",
       x = "Simulated satisfaction rate", y = "Density", fill = NULL, color = NULL) +
  theme_minimal(base_size = 9)
dir.create("figs", showWarnings = FALSE)
dir.create("../figs", showWarnings = FALSE)
ggsave("../figs/ppc_subgroups.png", p_ppc, width = 9, height = 3.5, dpi = 150)
p_ppc


## ----loss-function, fig.width=7, fig.height=4.5-------------------------------
expected_cost <- function(probs, labels, threshold, c_miss, c_waste) {
  flagged <- probs < threshold
  miss  <- sum(!flagged & labels == 0)   # dissatisfied, not flagged
  waste <- sum(flagged & labels == 1)    # satisfied, flagged anyway
  (c_miss * miss + c_waste * waste) / length(labels)
}

thresholds <- seq(0.05, 0.95, by = 0.01)
cost_ratios <- list("1:1 (equal cost)" = c(1, 1), "3:1" = c(3, 1), "5:1" = c(5, 1))

cost_df <- bind_rows(lapply(names(cost_ratios), function(nm) {
  cm <- cost_ratios[[nm]]
  data.frame(threshold = thresholds,
             cost = sapply(thresholds, expected_cost, probs = p_s3, labels = test$y,
                            c_miss = cm[1], c_waste = cm[2]),
             ratio = nm)
}))

optimal_tbl <- cost_df %>% group_by(ratio) %>% slice_min(cost, n = 1) %>%
  select(ratio, threshold, cost)

ggplot(cost_df, aes(threshold, cost, color = ratio)) +
  geom_line(linewidth = 1) +
  geom_point(data = optimal_tbl, size = 3) +
  labs(title = "Expected cost per customer vs. decision threshold",
       subtitle = "Points mark the cost-minimising threshold for each cost ratio",
       x = "Threshold t (flag as at-risk if predicted P(satisfied) < t)",
       y = "Expected cost per customer (arbitrary units)", color = "Cost ratio\n(miss:waste)") +
  theme_minimal(base_size = 10)

knitr::kable(optimal_tbl, digits = 3, caption = "Cost-minimising threshold by assumed cost ratio")

