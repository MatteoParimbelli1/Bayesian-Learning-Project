## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE,
                       fig.align = "center", cache = FALSE)

library(dplyr)
library(tidyr)
library(ggplot2)
library(rjags)
library(coda)
library(loo)
library(bayesplot)

rm(list = ls())


## ----load-data----------------------------------------------------------------
train <- read.csv("../data/airline_train_n1200.csv", stringsAsFactors = FALSE)
train$y <- as.integer(train$satisfaction == "satisfied")


## ----covariate-prep-----------------------------------------------------------
std <- function(x) as.numeric(scale(x))

service_items <- c("seat_comfort", "time_convenient", "food_drink", "gate_location", "wifi", "entertainment", "online_support", "ease_booking", "onboard_service", "legroom", "baggage", "checkin", "cleanliness", "online_boarding")
X_service <- apply(train[, service_items], 2, std)

logdep_std      <- std(train$log_dep_delay)
Age_std         <- std(train$age)
FlightDist_std  <- std(train$flight_distance)
logmid_delay    <- std(train$log_mid_delay)

names(train)

Class_EcoPlus  <- as.integer(train$class == "Eco Plus")
Class_Business <- as.integer(train$class == "Business")
TypeTravel_Personal <- as.integer(train$travel_type == "Personal Travel")
CustType_disloyal   <- as.integer(train$customer_type == "disloyal Customer")

X_extra <- cbind(Age_std, FlightDist_std, Class_EcoPlus, Class_Business, logdep_std, TypeTravel_Personal, CustType_disloyal)

X_full <- cbind(X_service, X_extra)
P <- ncol(X_full)


## ----model-code---------------------------------------------------------------
model_code <- '
model {
  for (i in 1:n) {
    y[i] ~ dbern(p[i])
    logit(p[i]) <- beta0 + inprod(X[i,], beta) + beta_arr * arr_delay[i]
    log_lik[i] <- logdensity.bern(y[i], p[i])
    arr_delay[i] ~ dnorm(0, 1)
  }
  beta0 ~ dnorm(0, 0.01)

  for (j in 1:P) {
    beta[j] ~ dnorm(0, prec_beta[j])
    prec_beta[j] <- 1 / (lambda[j] * lambda[j] * tau * tau)
    lambda[j] ~ dt(0, 1, 1) T(0, )
  }

  beta_arr ~ dnorm(0, prec_arr)
  prec_arr <- 1 / (lambda_arr * lambda_arr * tau * tau)
  lambda_arr ~ dt(0, 1, 1) T(0, )

  tau ~ dt(0, 1, 1) T(0, )
}'


## ----fit-horseshoe, cache=TRUE------------------------------------------------
set.seed(123)

# adjust these values to tune MCMC convergence
n_chains  = 3
n_adapt   = 5000
burn_in   = 1000
iter      = 30000
thinning  = 3


dataList <- list(y = train$y, X = X_full, arr_delay = logmid_delay,
                  n = nrow(X_full), P = P)

m <- jags.model(
  textConnection(model_code), 
  data = dataList,
  n.chains = n_chains, 
  n.adapt = n_adapt, 
  quiet = TRUE
  )

update(m, burn_in)

samples <- coda.samples(
  m, 
  variable.names = c("beta0", "beta", "beta_arr","lambda", "lambda_arr", "tau", "log_lik"), 
  n.iter = iter, 
  thin = thinning
  )


## -----------------------------------------------------------------------------
beta_cols <- c(paste0("beta[", 1:P, "]"), "beta0", "beta_arr")
# for traceplots and acf plots
groups_beta <- split(beta_cols, ceiling(seq_along(beta_cols) / 6))  # ~4 plots of 6

gd_beta <- gelman.diag(samples[, beta_cols], multivariate = FALSE)
gd_beta

beta_df <- data.frame( 
  ESS = effectiveSize(samples[, beta_cols])
)
knitr::kable(beta_df)


## ----fig.width=20, fig.height=12----------------------------------------------
for (g in groups_beta) {
  print(
    mcmc_trace(samples[, g], facet_args = list(ncol = 2)) +
    theme_minimal(base_size = 11) +
    theme(
      strip.text = element_text(size = 16, face = "bold"),
      axis.text.y = element_text(size = 14),
      panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
    ) +
    vline_0(color = "grey40", linetype = "dashed")
  )
}


## ----fig.width=20, fig.height=12----------------------------------------------

for(i in 1:n_chains){
  for (g in groups_beta) {
    print(
      mcmc_acf(samples[[i]][, g], facet_args = list(ncol = 2)) +    
        theme_minimal(base_size = 11) +
        theme(
          strip.text = element_text(size = 16, face = "bold"),
          axis.text.y = element_text(size = 14),
          panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
        ) +
        vline_0(color = "grey40", linetype = "dashed")
    )
  }
}


## ----fig.width=20, fig.height=12----------------------------------------------
lambda_cols <- c(paste0("lambda[", 1:P, "]"), "lambda_arr", "tau")
groups_lambda <- split(lambda_cols, ceiling(seq_along(lambda_cols) / 6))  # ~4 plots of 6

gd_lambda <- gelman.diag(samples[, lambda_cols], multivariate = FALSE)
gd_lambda

lambda_df <- data.frame( 
  ESS = effectiveSize(samples [, lambda_cols])
)
knitr::kable(lambda_df)


## ----fig.width=20, fig.height=12----------------------------------------------
for (g in groups_lambda) {
  print(
    mcmc_trace(samples[, g], facet_args = list(ncol = 2)) +
      theme_minimal(base_size = 11) +
      theme(
        strip.text = element_text(size = 16, face = "bold"),
        axis.text.y = element_text(size = 14),
        panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
      ) +
      vline_0(color = "grey40", linetype = "dashed")
   )
}   


## ----fig.width=20, fig.height=12----------------------------------------------
for(i in 1:n_chains){
  for (g in groups_lambda) {
    print(
      mcmc_acf(samples[[i]][, g], facet_args = list(ncol = 2)) +    
        theme_minimal(base_size = 11) +
        theme(
          strip.text = element_text(size = 16, face = "bold"),
          axis.text.y = element_text(size = 14),
          panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
        ) +
        vline_0(color = "grey40", linetype = "dashed")
    )
  }
}


## ----fig.width=20, fig.height=12----------------------------------------------
# potserior distirbution

for (g in groups_beta) {
  print(
    mcmc_areas(samples[, g], prob = 0.98) +
      theme_minimal(base_size = 11) +
      theme(
        axis.text.y = element_text(size = 24),
        axis.text.x = element_text(size = 24),
        panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
      ) +
      vline_0(color = "grey40", linetype = "dashed")
  )
}


## ----kappa-compute------------------------------------------------------------

sm <- as.matrix(samples)
beta_cols_only   <- c(paste0("beta[", 1:P, "]"), "beta_arr")
lambda_cols_only <- c(paste0("lambda[", 1:P, "]"), "lambda_arr")

beta_mat   <- sm[, beta_cols_only]
lambda_mat <- sm[, lambda_cols_only]
kappa_mat  <- 1 / (1 + lambda_mat^2)

post_beta  <- colMeans(beta_mat)
post_kappa <- colMeans(kappa_mat)
names(post_kappa) <- beta_cols_only
beta_ci <- apply(beta_mat, 2, quantile, c(0.025, 0.975))

term_labels <- c(
  "beta[1]" = "Seat comfort", "beta[2]" = "Dep/Arr time convenient", "beta[3]" = "Food and drink",
  "beta[4]" = "Gate location", "beta[5]" = "Inflight wifi service", "beta[6]" = "Inflight entertainment",
  "beta[7]" = "Online support", "beta[8]" = "Ease of Online booking", "beta[9]" = "On-board service",
  "beta[10]" = "Leg room service", "beta[11]" = "Baggage handling", "beta[12]" = "Checkin service",
  "beta[13]" = "Cleanliness", "beta[14]" = "Online boarding", "beta[15]" = "Age", "beta[16]" = "Flight Distance",
  "beta[17]" = "Class: Eco Plus", "beta[18]" = "Class: Business", "beta[19]" = "log(1+Departure Delay)",
  "beta[20]" = "Personal Travel", "beta[21]" = "disloyal Customer", "beta_arr" = "Mid-flight delay"
)

kappa_tbl <- data.frame(
  term = term_labels[beta_cols_only],
  kappa = round(post_kappa[beta_cols_only], 3),
  beta_mean = round(post_beta[beta_cols_only], 3),
  beta_lo = round(beta_ci[1, beta_cols_only], 3),
  beta_hi = round(beta_ci[2, beta_cols_only], 3)
) %>% arrange(kappa)

knitr::kable(kappa_tbl, row.names = FALSE,
             caption = "kappa_j near 0 = signal (unshrunk); near 1 = shrunk towards noise")


## ----kappa-plot, fig.width=8, fig.height=6------------------------------------
# plot shrinkage coefficients k

kappa_df <- as.data.frame(kappa_mat)
colnames(kappa_df) <- term_labels[beta_cols_only]
kappa_long <- pivot_longer(kappa_df, cols = everything(), names_to = "Predictor", values_to = "Kappa")
kappa_long$Predictor <- factor(kappa_long$Predictor,
                               levels = kappa_tbl$term[order(-kappa_tbl$kappa)])

ggplot(kappa_long, aes(x = Predictor, y = Kappa)) +
  geom_violin(fill = "steelblue", alpha = 0.7, scale = "width") +
  geom_hline(yintercept = 0.5, color = "red", linetype = "dashed") +
  coord_flip() +
  labs(title = "Horseshoe shrinkage weights",
       subtitle = expression("near 0 (right) = signal preserved; near 1 (left) = shrunk towards zero"),
       y = expression(kappa[j]), x = NULL) +
  theme_minimal(base_size = 10)


## ----beta-plot, fig.width=7, fig.height=6-------------------------------------
kappa_tbl %>%
  mutate(term = factor(term, levels = term[order(kappa)])) %>%
  ggplot(aes(x = beta_mean, y = term, color = kappa < 0.5)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey40") +
  geom_errorbarh(aes(xmin = beta_lo, xmax = beta_hi), height = 0.2) +
  geom_point(size = 2.2) +
  scale_color_manual(values = c("TRUE" = "#185FA5", "FALSE" = "grey60"), guide = "none") +
  labs(title = "Posterior coefficients under the horseshoe prior",
       subtitle = "Blue = kappa < 0.5 (signal); grey = kappa >= 0.5 (shrunk)",
       x = expression(beta[j]), y = NULL) +
  theme_minimal(base_size = 10)


## -----------------------------------------------------------------------------
# store horseshoe MCMC for later analyses

beta0_summary <- c(mean = mean(sm[, "beta0"]),
                   quantile(sm[, "beta0"], c(0.025, 0.975)))
tau_summary   <- c(mean = mean(sm[, "tau"]),
                   quantile(sm[, "tau"],   c(0.025, 0.975)))
saveRDS(list(
  post_kappa  = post_kappa, 
  post_beta   = post_beta, 
  beta_ci     = beta_ci,
  beta0       = beta0_summary,
  tau         = tau_summary,
  term_labels = term_labels, 
  beta_cols   = beta_cols_only,
  lambda_cols = lambda_cols_only
  ), "../data/03_horseshoe_summary.rds")


## -----------------------------------------------------------------------------
loglik_mat <- sm[, grepl("^log_lik", colnames(sm))]
loo_final <- loo::loo(loglik_mat)
waic_final <- loo::waic(loglik_mat)

beta_draws <- sm[, c("beta0", beta_cols_only)]

service_means <- colMeans(train[, service_items])
service_sds   <- apply(train[, service_items], 2, sd)

standardization <- list(
  service_means = service_means, service_sds = service_sds,
  Age_mean = mean(train$age), Age_sd = sd(train$age),
  FlightDist_mean = mean(train$flight_distance), FlightDist_sd = sd(train$flight_distance),
  logDepDelay_mean = mean(train$log_dep_delay), logDepDelay_sd = sd(train$log_dep_delay),
  logmid_mean = mean(train$log_mid_delay), logmid_sd = sd(train$log_mid_delay)
)

saveRDS(list(
  loo = loo_final, 
  waic = waic_final, 
  kappa_tbl = kappa_tbl,
  beta_draws = beta_draws, 
  standardization = standardization,
  service_items = service_items), "../data/03_horseshoe_final.rds")

