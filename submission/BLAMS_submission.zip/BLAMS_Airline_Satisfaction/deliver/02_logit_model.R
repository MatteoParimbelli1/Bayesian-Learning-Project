## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE,
                      fig.align = "center", cache = FALSE)

library(dplyr)
library(tidyr)
library(ggplot2)
library(rjags)
library(coda)
library(loo)
library(bayesplot)

rm(list = ls())


## ----load-data----------------------------------------------------------------
train <- read.csv("../data/airline_train_n1200.csv", stringsAsFactors = FALSE)
train$y <- as.integer(train$satisfaction == "satisfied")
n_train <- nrow(train)


## -----------------------------------------------------------------------------
# helper function to standardize covariates and make them numeric
std <- function(x) as.numeric(scale(x))

logdep_std      <- std(train$log_dep_delay)
Age_std         <- std(train$age)
Seat_std        <- std(train$seat_comfort)
FlightDist_std  <- std(train$flight_distance)
TypeTravel_Personal <- as.integer(train$travel_type == "Personal Travel")
CustType_disloyal   <- as.integer(train$customer_type == "disloyal Customer")

logmid_delay    <- std(train$log_mid_delay)

Class_EcoPlus   <- as.integer(train$class == "Eco Plus")
Class_Business  <- as.integer(train$class == "Business")
Class_score_std <- std(as.integer(factor(train$class, levels = c("Eco", "Eco Plus", "Business"), ordered = TRUE)))


X_dummy <- cbind(Age_std, Seat_std, FlightDist_std, Class_EcoPlus, Class_Business,
                 logdep_std, TypeTravel_Personal, CustType_disloyal)

X_ordinal <- cbind(Age_std, Seat_std, FlightDist_std, Class_score_std,
                   logdep_std, TypeTravel_Personal, CustType_disloyal)



## ----model-code---------------------------------------------------------------
model_string = 'model {
  for (i in 1:n) {
    y[i] ~ dbern(p[i])
    logit(p[i]) <- beta0 + inprod(X[i,], beta) + beta_arr * arr_delay[i]
    log_lik[i] <- logdensity.bern(y[i], p[i])
    arr_delay[i] ~ dnorm(0, 1)
  }
  beta0 ~ dnorm(0, 0.01)
  beta_arr ~ dnorm(0, 0.01)
  for (j in 1:P) { beta[j] ~ dnorm(0, 0.01) }
}'


## ----fit-function-------------------------------------------------------------

n_chains  = 3
n_adapt   = 1500
burn_in   = 1000
iter      = 12000
thinning  = 7

fit_model <- function(model_string, X, arr_delay,
                      n.chains = n_chains, 
                      n.adapt = n_adapt, 
                      burn = burn_in, 
                      n.iter = iter, 
                      thin = thinning) 
  {
    dataList <- list(
      y = train$y, 
      X = X, 
      arr_delay = arr_delay, 
      n = nrow(X), 
      P = ncol(X)
      )
    
    m <- jags.model(textConnection(model_string), data = dataList,
                    n.chains = n.chains, n.adapt = n.adapt, quiet = TRUE)
    update(m, burn)
    coda.samples(m, variable.names = c("beta0", "beta", "beta_arr", "log_lik"),
                 n.iter = n.iter, thin = thin)
  }
  
  extract_loglik <- function(samples) {
    sm <- as.matrix(samples)
    sm[, grepl("^log_lik", colnames(sm))]
  }



## ----fit-encoding, cache=TRUE, cache.extra=list(n_chains, n_adapt, burn_in, iter, thinning)----
set.seed(123)

fit_dummy_logit   <- fit_model(model_string, X_dummy,   logmid_delay)
fit_ordinal_logit <- fit_model(model_string, X_ordinal, logmid_delay)

w_dummy   <- waic(extract_loglik(fit_dummy_logit))
w_ordinal <- waic(extract_loglik(fit_ordinal_logit))
cmp_encoding <- loo_compare(list(dummy = w_dummy, ordinal = w_ordinal))


## ----encoding-waic-print------------------------------------------------------
cat("Dummy encoding:\n");   print(w_dummy)
cat("\nOrdinal encoding:\n"); print(w_ordinal)
cat("\nComparison (positive elpd_diff favors the row):\n"); print(cmp_encoding)


## ----encoding-oos-validate, cache=TRUE----------------------------------------
# Held-out test set, same preprocessing pipeline as the training file --
# adjust the path / column names below if your test export differs
test <- read.csv("../data/airline_test_holdout.csv", stringsAsFactors = FALSE)
test$y <- as.integer(test$satisfaction == "satisfied")

# Standardize test covariates using TRAINING mean/sd -- never re-scale on test data
std_with <- function(x, m, s) (x - m) / s

Age_std_test        <- std_with(test$age, mean(train$age), sd(train$age))
Seat_std_test       <- std_with(test$seat_comfort, mean(train$seat_comfort), sd(train$seat_comfort))
FlightDist_std_test <- std_with(test$flight_distance, mean(train$flight_distance), sd(train$flight_distance))
logdep_std_test     <- std_with(test$log_dep_delay, mean(train$log_dep_delay), sd(train$log_dep_delay))
logmid_test         <- std_with(test$log_mid_delay, mean(train$log_mid_delay), sd(train$log_mid_delay))

TypeTravel_Personal_test <- as.integer(test$travel_type == "Personal Travel")
CustType_disloyal_test   <- as.integer(test$customer_type == "disloyal Customer")

Class_EcoPlus_test  <- as.integer(test$class == "Eco Plus")
Class_Business_test <- as.integer(test$class == "Business")

class_int_train <- as.integer(factor(train$class, levels = c("Eco", "Eco Plus", "Business"), ordered = TRUE))
class_int_test  <- as.integer(factor(test$class,  levels = c("Eco", "Eco Plus", "Business"), ordered = TRUE))
Class_score_std_test <- std_with(class_int_test, mean(class_int_train), sd(class_int_train))

X_dummy_test   <- cbind(Age_std_test, Seat_std_test, FlightDist_std_test,
                        Class_EcoPlus_test, Class_Business_test,
                        logdep_std_test, TypeTravel_Personal_test, CustType_disloyal_test)
X_ordinal_test <- cbind(Age_std_test, Seat_std_test, FlightDist_std_test, Class_score_std_test,
                        logdep_std_test, TypeTravel_Personal_test, CustType_disloyal_test)

# Posterior-mean predicted probability on the test set, averaged over the MCMC
# draws we already have -- reuses fit_dummy_logit / fit_ordinal_logit from 1.1
predict_p <- function(fit, X, arr_delay) {
  sm         <- as.matrix(fit)
  beta0_dr   <- sm[, "beta0"]
  beta_dr    <- sm[, grep("^beta\\[", colnames(sm)), drop = FALSE]
  betaarr_dr <- sm[, "beta_arr"]
  eta <- beta0_dr + beta_dr %*% t(X) + outer(betaarr_dr, arr_delay)
  colMeans(plogis(eta))
}

p_dummy_test   <- predict_p(fit_dummy_logit,   X_dummy_test,   logmid_test)
p_ordinal_test <- predict_p(fit_ordinal_logit, X_ordinal_test, logmid_test)

# Out-of-sample scoring: log-loss, Brier score, AUC (rank-based, no extra package)
auc_manual <- function(p, y) {
  r  <- rank(p)
  n1 <- as.numeric(sum(y == 1))
  n0 <- as.numeric(sum(y == 0))
  (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

oos_metrics <- function(p, y) {
  eps <- 1e-9
  p <- pmin(pmax(p, eps), 1 - eps)
  c(log_loss = -mean(y * log(p) + (1 - y) * log(1 - p)),
    brier    = mean((p - y)^2),
    auc      = auc_manual(p, y))
}

oos_cmp <- rbind(
  dummy   = oos_metrics(p_dummy_test,   test$y),
  ordinal = oos_metrics(p_ordinal_test, test$y)
)
knitr::kable(round(oos_cmp, 4))


## ----diagnostics--------------------------------------------------------------
final_fit <- fit_dummy_logit

beta_cols <- colnames(as.matrix(final_fit))[!grepl("^log_lik", colnames(as.matrix(final_fit)))]

gd  <- gelman.diag(final_fit[, beta_cols])
gd

diag_df <- data.frame( 
  ESS = effectiveSize(final_fit[, beta_cols])
)
knitr::kable(diag_df)


## ----fig.width=20, fig.height=12----------------------------------------------

mcmc_trace(final_fit[, beta_cols]) +
theme_minimal(base_size = 11) +
  theme(
    strip.text = element_text(size = 16, face = "bold"),
    axis.text.y = element_text(size = 14),
    panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
  ) +
  vline_0(color = "grey40", linetype = "dashed")


## ----fig.width=20, fig.height=12----------------------------------------------
for(i in 1:n_chains){
  print(
    mcmc_acf(final_fit[[i]][, beta_cols]) +    
      theme_minimal(base_size = 11) +
      theme(
        strip.text = element_text(size = 16, face = "bold"),
        axis.text.y = element_text(size = 14),
        panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
      ) +
      vline_0(color = "grey40", linetype = "dashed")
  )
}


## ----fig.width=20, fig.height=12----------------------------------------------
groups <- list(
  continuous = c("beta[1]", "beta[2]", "beta[3]", "beta[6]", "beta_arr"),
  class      = c("beta[4]", "beta[5]"),
  binary     = c("beta[7]", "beta[8]", "beta0")
)

for (g in groups) {
  print(
    mcmc_areas(final_fit[, g], prob = 0.98) +
    theme_minimal(base_size = 11) +
      theme(
        axis.text.y = element_text(size = 24),
        axis.text.x = element_text(size = 24),
        panel.grid.major.x = element_line(color = "grey85", linewidth = 0.3)
      ) +
    vline_0(color = "grey40", linetype = "dashed")
        )
}


## ----odds-ratios--------------------------------------------------------------
sm <- as.matrix(final_fit)
sm_beta <- sm[, beta_cols]

term_labels <- c(
  "beta0" = "Intercept",
  "beta[1]" = "Age",
  "beta[2]" = "Seat comfort",
  "beta[3]" = "Flight Distance",
  "beta[4]" = "Class: Eco Plus (vs Eco)",
  "beta[5]" = "Class: Business (vs Eco)",
  "beta[6]" = "log(1+Departure Delay)",
  "beta[7]" = "Personal Travel (vs Business travel)",
  "beta[8]" = "disloyal Customer (vs Loyal)",
  "beta_arr" = "Mid-flight delay (signed-log)"
)

post_mean <- colMeans(sm_beta)
post_ci   <- apply(sm_beta, 2, quantile, c(0.025, 0.975))

or_tbl <- data.frame(
  term = term_labels[names(post_mean)],
  beta_mean = round(post_mean, 3),
  beta_lo = round(post_ci[1, ], 3), beta_hi = round(post_ci[2, ], 3),
  OR = round(exp(post_mean), 3),
  OR_lo = round(exp(post_ci[1, ]), 3), OR_hi = round(exp(post_ci[2, ]), 3)
) %>% arrange(desc(OR))

knitr::kable(or_tbl, row.names = FALSE)


## ----or-plot, fig.width=7, fig.height=4.5-------------------------------------
or_tbl %>%
  filter(term != "Intercept") %>%
  mutate(term = factor(term, levels = term[order(OR)]),
         significant = OR_lo > 1 | OR_hi < 1) %>%
  ggplot(aes(x = OR, y = term, color = significant)) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey40") +
  geom_errorbarh(aes(xmin = OR_lo, xmax = OR_hi), height = 0.2) +
  geom_point(size = 2.5) +
  scale_color_manual(values = c("TRUE" = "#185FA5", "FALSE" = "grey60"), guide = "none") +
  scale_x_log10() +
  labs(title = "Posterior odds ratios, logit model with dummy Class encoding",
       subtitle = "95% credible intervals; dashed line = no effect",
       x = "Odds ratio (log scale)", y = NULL) +
  theme_minimal(base_size = 11)


## ----export-------------------------------------------------------------------

final_loglik <- extract_loglik(final_fit)
loo_final <- loo::loo(final_loglik)
waic_final <- loo::waic(final_loglik)

sm_final <- as.matrix(final_fit)
beta_draws <- sm_final[, beta_cols]

standardization <- list(
  Age_mean = mean(train$age), Age_sd = sd(train$age),
  Seat_mean = mean(train$seat_comfort), Seat_sd = sd(train$seat_comfort),
  FlightDist_mean = mean(train$flight_distance), FlightDist_sd = sd(train$flight_distance),
  logdep_mean = mean(train$log_dep_delay), logDepDelay_sd = sd(train$log_dep_delay),
  logmid_mean = mean(train$log_mid_delay), logmid_sd = sd(train$log_mid_delay)
)

saveRDS(list(
  loo = loo_final, 
  waic = waic_final,
  beta_mean = post_mean, 
  beta_ci = post_ci, 
  or_tbl = or_tbl,
  beta_draws = beta_draws, 
  standardization = standardization
), "../data/02_logit_mcmc.rds")

