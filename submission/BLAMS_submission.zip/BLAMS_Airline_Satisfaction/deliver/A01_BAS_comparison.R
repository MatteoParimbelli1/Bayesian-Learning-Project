## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE,
                       fig.align = "center", cache = FALSE)

library(dplyr)
library(tidyr)
library(ggplot2)
library(BAS)

rm(list = ls())


## ----load-data----------------------------------------------------------------
train <- read.csv("../data/airline_train_n1200.csv", stringsAsFactors = FALSE)
train$y <- as.integer(train$satisfaction == "satisfied")

std <- function(x) as.numeric(scale(x))

service_items <- c("seat_comfort", "time_convenient", "food_drink", "gate_location", "wifi", "entertainment", "online_support", "ease_booking", "onboard_service","legroom", "baggage", "checkin", "cleanliness", "online_boarding" )
X_service <- apply(train[, service_items], 2, std)

logdep_std      <- std(train$log_dep_delay)
Age_std         <- std(train$age)
FlightDist_std  <- std(train$flight_distance)
logmid_delay    <- std(train$log_mid_delay)

Class_EcoPlus  <- as.integer(train$class == "Eco Plus")
Class_Business <- as.integer(train$class == "Business")
TypeTravel_Personal <- as.integer(train$travel_type == "Personal Travel")
CustType_disloyal   <- as.integer(train$customer_type == "disloyal Customer")

X_extra <- cbind(Age_std, FlightDist_std, Class_EcoPlus, Class_Business,
                 logdep_std, TypeTravel_Personal, CustType_disloyal, logmid_delay)
X_full <- cbind(X_service, X_extra)

df_bas <- data.frame(y = train$y, X_full)


## ----fit-glm-g----------------------------------------------------------------
set.seed(123)
fit_glm_g <- bas.glm(y ~ ., data = df_bas, family = binomial(),
                      betaprior = g.prior(nrow(df_bas)), modelprior = uniform(),
                      method = "MCMC", MCMC.iterations = 100000)


## ----top-models---------------------------------------------------------------
knitr::kable(round(summary(fit_glm_g, n.models = 5), 3),
                          caption = "Top 5 models by posterior probability (g-prior)")


## ----diagnostics-plot, fig.width=5, fig.height=5------------------------------
diag_df <- data.frame(renormalized = fit_glm_g$probne0.RN,
                       mcmc = fit_glm_g$probne0.MCMC)
ggplot(diag_df, aes(renormalized, mcmc)) +
  geom_point(color = "#185FA5", alpha = 0.7) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey40") +
  coord_equal(xlim = c(0,1), ylim = c(0,1)) +
  labs(title = "MCMC convergence check: PIP estimates should lie on the diagonal",
       x = "PIP (renormalized marginal likelihood)", y = "PIP (raw MCMC frequency)") +
  theme_minimal(base_size = 11)


## ----seed-stability, cache=TRUE-----------------------------------------------
run_seed <- function(seed) {
  set.seed(seed)
  fit <- bas.glm(y ~ ., data = df_bas, family = binomial(),
                 betaprior = g.prior(nrow(df_bas)), modelprior = uniform(),
                 method = "MCMC", MCMC.iterations = 100000)
  fit$probne0
}
pip_seed1 <- run_seed(1)
pip_seed2 <- run_seed(2)

pip_df <- data.frame(term = fit_glm_g$namesx,
                      seed123 = fit_glm_g$probne0,
                      seed1 = pip_seed1, seed2 = pip_seed2)
pip_df$range <- apply(pip_df[, 2:4], 1, function(x) max(x) - min(x))


## ----seed-stability-table-----------------------------------------------------
knitr::kable(pip_df %>% arrange(desc(range)) %>% head(8), row.names = FALSE, digits = 3,
             caption = "Largest PIP swings across 3 seeds (of 22 predictors)")
cat(sprintf("Max PIP range across seeds: %.3f\nMean PIP range across seeds: %.4f\n",
            max(pip_df$range), mean(pip_df$range)))


## ----bic-prior, cache=TRUE----------------------------------------------------
set.seed(123)
fit_glm_bic <- bas.glm(y ~ ., data = df_bas, family = binomial(),
                        betaprior = bic.prior(nrow(df_bas)), modelprior = uniform(),
                        method = "MCMC", MCMC.iterations = 100000)

cmp_prior <- data.frame(term = fit_glm_g$namesx, g_prior = round(fit_glm_g$probne0, 3),
                         BIC = round(fit_glm_bic$probne0, 3))
cmp_prior$abs_diff <- round(abs(cmp_prior$g_prior - cmp_prior$BIC), 3)


## ----bic-table----------------------------------------------------------------
knitr::kable(cmp_prior %>% arrange(desc(abs_diff)) %>% head(6), row.names = FALSE,
             caption = "Largest g-prior vs. BIC-prior PIP differences")
cat("Max |g-prior - BIC| difference:", max(cmp_prior$abs_diff), "\n")


## -----------------------------------------------------------------------------
hs <- readRDS("../data/03_horseshoe_summary.rds")
hs_names_raw <- c("seat_confort", "time_convenience", "food_drink",
                   "gate_location", "wifi", "entertainment",
                   "online_support", "ease_booking", "onboard_service",
                   "legroom", "baggage", "checkin",
                   "cleanliness", "online_boarding", "Age_std", "FlightDist_std",
                   "Class_EcoPlus", "Class_Business", "logdep_std",
                   "TypeTravel_Personal", "CustType_disloyal", "logmid_delay")
kappa_ordered <- hs$post_kappa[c(paste0("beta[", 1:21, "]"), "beta_arr")]

names(kappa_ordered)
length(hs$post_kappa)

cmp_methods <- data.frame(term = hs_names_raw,
                           PIP = round(fit_glm_g$probne0[-1], 3),
                           kappa = round(kappa_ordered, 3))
cmp_methods$signal_BAS <- cmp_methods$PIP > 0.5
cmp_methods$signal_HS  <- cmp_methods$kappa < 0.5
cmp_methods$agree <- cmp_methods$signal_BAS == cmp_methods$signal_HS
cmp_methods %>% filter(!agree)
agreement_rate <- mean(cmp_methods$agree)
print("two methods agreement rate is: ")
agreement_rate


## ----hs-comparison-plot, fig.width=7, fig.height=6----------------------------
cmp_methods %>%
  mutate(term = factor(term, levels = term[order(PIP)])) %>%
  ggplot(aes(x = PIP, y = 1 - kappa, color = agree, shape = agree)) +
  geom_point(size = 3) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "grey60") +
  geom_vline(xintercept = 0.5, linetype = "dashed", color = "grey60") +
  scale_color_manual(values = c("TRUE" = "#0072B2", "FALSE" = "#D55E00"),
                      labels = c("TRUE" = "Agree", "FALSE" = "Disagree"), name = NULL) +
  scale_shape_manual(values = c("TRUE" = 16, "FALSE" = 17),
                      labels = c("TRUE" = "Agree", "FALSE" = "Disagree"), name = NULL) +
  labs(title = "BAS posterior inclusion probability vs. horseshoe (1 - kappa)",
       subtitle = sprintf("%.0f%% agreement on signal (>0.5) vs. noise (<=0.5)", 100*agreement_rate),
       x = "PIP (BAS, g-prior)", y = expression(1 - kappa[j]~"(horseshoe)")) +
  theme_minimal(base_size = 10)


## ----export-bas---------------------------------------------------------------
saveRDS(fit_glm_g, "../data/A01_BAS_model.rds")

