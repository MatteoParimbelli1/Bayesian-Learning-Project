## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE,
                      fig.align = "center", cache = FALSE)

library(dplyr)
library(tidyr)
library(ggplot2)
library(here)
# loo_compare() is used by the model-comparison chunk below
library(loo)

rm(list = ls())


## ----load-data----------------------------------------------------------------
train <- read.csv("../data/airline_train_n1200.csv", stringsAsFactors = FALSE)
train$y <- as.integer(train$satisfaction == "satisfied")
std <- function(x) as.numeric(scale(x))


## ----vague-term-labels--------------------------------------------------------
# Coefficient order returned by the sweep: beta[1..8], beta0, beta_arr.
term_labels_vague <- c("beta0" = "Intercept", "beta[1]" = "Age", "beta[2]" = "Seat comfort",
                       "beta[3]" = "Flight Distance", "beta[4]" = "Class: Eco Plus",
                       "beta[5]" = "Class: Business", "beta[6]" = "log(1+Departure Delay)",
                       "beta[7]" = "Personal Travel", "beta[8]" = "disloyal Customer",
                       "beta_arr" = "Mid-flight delay (signed-log)")


## ----prior-sweep-load---------------------------------------------------------
sweep_results <- readRDS("../data/04a_prior_sweep.rds")


## ----prior-sweep-plot, fig.width=8, fig.height=6------------------------------
sweep_df <- bind_rows(lapply(names(sweep_results), function(v) {
  df <- sweep_results[[v]]
  df$term <- rownames(df)
  df$variance <- v
  df
}))
sweep_df$term_label <- term_labels_vague[sweep_df$term]
sweep_df$variance <- factor(sweep_df$variance,
                            levels = c("1", "10", "100", "10000"))

ggplot(sweep_df, aes(x = mean, y = term_label, color = variance)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey40") +
  geom_errorbarh(aes(xmin = lo, xmax = hi), height = 0.2,
                 position = position_dodge(width = 0.6)) +
  geom_point(position = position_dodge(width = 0.6), size = 2) +
  labs(title = "Posterior coefficients across four prior variances",
       subtitle = expression(sigma[beta]^2 %in% "{1, 10, 100, 10000}"),
       x = expression(beta), y = NULL, color = expression(sigma[beta]^2)) +
  theme_minimal(base_size = 10)


## ----prior-sweep-range--------------------------------------------------------
range_tbl <- sweep_df %>%
  group_by(term_label) %>%
  summarise(mean_range = max(mean) - min(mean), .groups = "drop") %>%
  arrange(desc(mean_range))
knitr::kable(range_tbl, digits = 4,
             caption = "Range of posterior means across the four prior variances")


## ----hs-sweep-load------------------------------------------------------------
hs_sweep <- readRDS("../data/04b_horseshoe_sweep.rds")
hs_scales <- names(hs_sweep)

hs_df <- bind_rows(lapply(hs_scales, function(s) {
  d <- hs_sweep[[s]]
  d$scale <- s
  d
}))
hs_df$scale <- factor(hs_df$scale, levels = hs_scales)


## ----hs-sweep-beta-plot, fig.width=9, fig.height=8----------------------------
ggplot(hs_df, aes(x = beta_mean, y = reorder(term, beta_mean), color = scale)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey40") +
  geom_errorbarh(aes(xmin = beta_lo, xmax = beta_hi), height = 0.25,
                 position = position_dodge(width = 0.6)) +
  geom_point(position = position_dodge(width = 0.6), size = 1.8) +
  labs(title = "Horseshoe posterior coefficients across three global scales",
       subtitle = expression(tau %~% "C+(0, s), s in {0.1, 1, 10}"),
       x = expression(beta[j]), y = NULL, color = "global scale s") +
  theme_minimal(base_size = 10)


## ----hs-sweep-beta-range------------------------------------------------------
hs_range <- hs_df %>%
  group_by(term) %>%
  summarise(beta_range = max(beta_mean) - min(beta_mean), .groups = "drop") %>%
  arrange(desc(beta_range))
knitr::kable(head(hs_range, 8), digits = 3,
             caption = "Largest movement of the posterior mean across the three global scales")


## ----hs-sweep-kappa-wide------------------------------------------------------
kappa_wide <- hs_df %>%
  select(term, scale, kappa) %>%
  pivot_wider(names_from = scale, values_from = kappa)
knitr::kable(kappa_wide, digits = 3,
             caption = "Posterior shrinkage weight kappa_j at each global scale")


## ----hs-sweep-signal-stability------------------------------------------------
signal_wide <- hs_df %>%
  mutate(signal = kappa < 0.5) %>%
  select(term, scale, signal) %>%
  pivot_wider(names_from = scale, values_from = signal)

signal_cols <- setdiff(names(signal_wide), "term")
signal_wide$stable <- apply(signal_wide[, signal_cols], 1,
                            function(r) length(unique(r)) == 1)
n_flips <- sum(!signal_wide$stable)

# predictors classified as signal (kappa < 0.5) under the default scale s = 1
default_signal <- signal_wide$term[signal_wide[["1"]]]

knitr::kable(signal_wide, caption = "Signal (kappa < 0.5) at each scale; `stable` = same verdict across all three")


## ----structural-zero-load-----------------------------------------------------
# Section 03 horseshoe summary (full data). The saved object holds the pieces,
# not an assembled table, so rebuild one with the same columns as the refit's
# result_tbl, otherwise the two cannot be bound together below.
s3   <- readRDS("../data/03_horseshoe_summary.rds")
s3$kappa_tbl <- data.frame(
  term      = s3$term_labels[s3$beta_cols],
  kappa     = as.numeric(s3$post_kappa[s3$beta_cols]),
  beta_mean = as.numeric(s3$post_beta[s3$beta_cols]),
  beta_lo   = as.numeric(s3$beta_ci[1, s3$beta_cols]),
  beta_hi   = as.numeric(s3$beta_ci[2, s3$beta_cols]),
  row.names = NULL)
zref <- readRDS("../data/04c_structural_zero_refit.rds")
cat("Rows excluded:", zref$n_excluded, "of", zref$n_excluded + zref$n_remaining, "\n")
cat("Rows remaining:", zref$n_remaining, "\n")


## ----structural-zero-table----------------------------------------------------
knitr::kable(zref$result_tbl, row.names = FALSE, digits = 3,
             caption = "Horseshoe refit excluding structural-zero rows")


## ----structural-zero-compare, fig.width=7, fig.height=5-----------------------
full_tbl <- s3$kappa_tbl %>% mutate(fit = "Full data")
zero_tbl <- zref$result_tbl %>% mutate(fit = "Excluding structural zeros")

compare_df <- bind_rows(full_tbl, zero_tbl) %>%
  filter(term %in% c("Dep/Arr time convenient", "Seat comfort", "Food and drink", "Gate location"))

ggplot(compare_df, aes(x = beta_mean, y = term, color = fit)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey40") +
  geom_errorbarh(aes(xmin = beta_lo, xmax = beta_hi), height = 0.15,
                 position = position_dodge(width = 0.4)) +
  geom_point(position = position_dodge(width = 0.4), size = 2.2) +
  labs(title = "The 'seat/catering/ground' cluster: full data vs. excluding structural zeros",
       x = expression(beta), y = NULL, color = NULL) +
  theme_minimal(base_size = 10)


## -----------------------------------------------------------------------------
## Model comparison: WAIC and PSIS-LOO

s2 <- readRDS("../data/02_logit_mcmc.rds")
s3 <- readRDS("../data/03_horseshoe_final.rds")

print(s2$loo)
print(s3$loo)

loo_cmp <- loo_compare(list(logit = s2$loo, horseshoe = s3$loo))
print(loo_cmp)


## -----------------------------------------------------------------------------
loo_tbl <- data.frame(
  Model = c("Vague-prior logit", "Horseshoe"),
  elpd_loo = c(s2$loo$estimates["elpd_loo","Estimate"], s3$loo$estimates["elpd_loo","Estimate"]),
  SE       = c(s2$loo$estimates["elpd_loo","SE"],       s3$loo$estimates["elpd_loo","SE"]),
  p_loo    = c(s2$loo$estimates["p_loo","Estimate"],    s3$loo$estimates["p_loo","Estimate"]),
  looic    = c(s2$loo$estimates["looic","Estimate"],    s3$loo$estimates["looic","Estimate"])
)
knitr::kable(round(loo_tbl[,-1], 1), row.names = FALSE)

