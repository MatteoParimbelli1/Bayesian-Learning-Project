# Airline Customer Satisfaction — Bayesian Learning and Monte Carlo Simulations

Guglielmi Leonardo · Marian Sorin Nicu · Parimbelli Matteo
Academic year 2025–2026 · Dataset 3

## Contents

- `Report.pdf` — the report.
- `deliver/` — the analysis. Each chapter of the report has one file.
- `data/` — the dataset and the fitted-model outputs, so the code runs without
  refitting.

## The code

Every analysis exists in two forms with identical content:

- `.Rmd` — the notebook, with the narrative explaining each step. Open in
  RStudio and press Knit.
- `.R` — the same code as a plain script, extracted with `knitr::purl`. Run
  with `Rscript`.

Run them from inside `deliver/`; the paths to `data/` are relative to it.

| file | what it does |
|---|---|
| `01_data_exploration` | cleaning, EDA, delay decorrelation, stratified train/test split |
| `02_logit_model` | logistic regression, vague N(0,100) priors, 9 predictors |
| `03_feature_selection` | horseshoe shrinkage prior over 22 predictors |
| `04_models_sensitivity` | reads the four sweeps below and compares the models |
| `05_prediction_validation` | out-of-sample accuracy, ROC/AUC, calibration, PPC |
| `A01_BAS_comparison` | `bas.glm` cross-check, appendix |

The four `04a`–`04d` scripts do the refits chapter 5 reports. They are separate
because each runs for minutes to the better part of an hour; their output is in
`data/`, so `04_models_sensitivity` runs immediately.

```bash
Rscript 04a_prior_sweep.R              # ~4 min
Rscript 04c_structural_zero_refit.R    # ~4 min
Rscript 04d_large_subsample_refit.R    # ~25 min
Rscript 04b_horseshoe_prior_sweep.R    # ~45 min
```

## Setup

JAGS is a standalone program, not an R package. Install it before `rjags`.
`rjags` needs JAGS **4.x** and will not build against JAGS 5, which is what
`brew install jags` currently gives; take 4.3.2 from the official installer.

```r
install.packages(c("rjags", "coda", "loo", "BAS", "dplyr", "tidyr",
                   "ggplot2", "RColorBrewer", "rmarkdown",
                   "bayesplot", "caret", "corrplot", "here"))
```

## Notes

- Everything uses `set.seed(2026)`. JAGS's internal RNG is not fully pinned by
  it, so small differences between machines are normal.
- `03` is the slow notebook: the half-Cauchy priors mix slowly and need a long
  burn-in and heavy thinning.
- Rerun `03` if you change the covariates. `04` and `05` read
  `data/03_horseshoe_final.rds`, and a stale copy does not error, it just gives
  coefficients that no longer match the design matrix.
- The delay term is `log_mid_delay`, the signed log of arrival minus departure.
  The residual `arr_delay_res` is the alternative Appendix A rejects; they
  correlate at −0.39 and are not interchangeable.
